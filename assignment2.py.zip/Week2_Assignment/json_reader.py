import json

with open("student.json", "r") as file:
    data = json.load(file)

print("Student Details")
print("----------------")
for key, value in data.items():
    print(f"{key}: {value}")