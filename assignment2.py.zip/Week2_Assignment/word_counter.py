filename = "sample.txt"

with open(filename, "r") as file:
    text = file.read()

words = len(text.split())
lines = len(text.splitlines())
characters = len(text)

print("Word Count:", words)
print("Line Count:", lines)
print("Character Count:", characters)