import csv
import os

filename = "students.csv"

if not os.path.exists(filename):
    with open(filename, "w", newline="") as file:
        writer = csv.writer(file)
        writer.writerow(["Roll No", "Name", "Marks"])


def add_student():
    roll = input("Enter Roll Number: ")
    name = input("Enter Name: ")
    marks = input("Enter Marks: ")

    with open(filename, "a", newline="") as file:
        writer = csv.writer(file)
        writer.writerow([roll, name, marks])

    print("Student Added Successfully!")


def search_student():
    roll = input("Enter Roll Number to Search: ")

    with open(filename, "r") as file:
        reader = csv.reader(file)
        next(reader)

        found = False
        for row in reader:
            if row[0] == roll:
                print("Roll:", row[0])
                print("Name:", row[1])
                print("Marks:", row[2])
                found = True
                break

        if not found:
            print("Student Not Found!")


def delete_student():
    roll = input("Enter Roll Number to Delete: ")

    rows = []

    with open(filename, "r") as file:
        reader = csv.reader(file)
        rows = list(reader)

    with open(filename, "w", newline="") as file:
        writer = csv.writer(file)

        for row in rows:
            if row[0] != roll:
                writer.writerow(row)

    print("Student Deleted Successfully!")


while True:
    print("\n===== Student Management System =====")
    print("1. Add Student")
    print("2. Search Student")
    print("3. Delete Student")
    print("4. Exit")

    choice = input("Enter Your Choice: ")

    if choice == "1":
        add_student()

    elif choice == "2":
        search_student()

    elif choice == "3":
        delete_student()

    elif choice == "4":
        print("Thank You!")
        break

    else:
        print("Invalid Choice!")